import SwiftUI

/// PRODUCTION SIGN-IN — native Supabase Auth over the real database.
///
/// The form collects credentials and, when founding a company, the details the
/// approved `create_company_and_owner()` RPC requires. It deliberately offers no
/// company or role field: both are decided server-side.
struct ProductionSignInView: View {
    @Environment(AppEnvironment.self) private var env

    private enum Flow: String, CaseIterable, Identifiable {
        case signIn
        case join
        case createCompany

        var id: String { rawValue }
        var title: String {
            switch self {
            case .signIn: return "Sign in"
            case .join: return "Join"
            case .createCompany: return "New company"
            }
        }
    }

    /// ISSUE #15 — the currencies a new company may be created in.
    ///
    /// Exactly the set the supported markets trade in, so an unsupported
    /// currency cannot be entered. Deduplicated because Ireland and any future
    /// euro market share one.
    private static let selectableCurrencyCodes: [String] = {
        var seen = Set<String>()
        return SupportedMarket.allCases
            .map(\.defaultCurrencyCode)
            .filter { seen.insert($0).inserted }
    }()

    @State private var flow: Flow = .signIn
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var ownerName: String = ""
    @State private var companyName: String = ""
    @State private var trade: Trade = .hvac
    /// ISSUE #15 — country and currency were two free-text boxes, so a company
    /// could be founded in a market Stripe Connect cannot serve and only find
    /// out on the day it tried to get paid. The market is now chosen from the
    /// list Harbour South actually supports, and it supplies the currency.
    @State private var market: SupportedMarket = .fallback
    @State private var currencyCode: String = SupportedMarket.fallback.defaultCurrencyCode
    @State private var joinName: String = ""
    @State private var joinCode: String = ""

    private var canSubmit: Bool {
        guard !env.authPhase.isBusy else { return false }
        let hasCredentials = email.contains("@") && password.count >= 6
        switch flow {
        case .signIn:
            return hasCredentials
        case .join:
            return hasCredentials
                && !joinName.trimmingCharacters(in: .whitespaces).isEmpty
                && joinCode.trimmingCharacters(in: .whitespaces).count >= 6
        case .createCompany:
            // The market picker cannot produce an invalid country, and the
            // currency picker is seeded from it, so neither needs a length check
            // any more — both are now closed sets rather than typed strings.
            return hasCredentials
                && !ownerName.trimmingCharacters(in: .whitespaces).isEmpty
                && !companyName.trimmingCharacters(in: .whitespaces).isEmpty
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            if env.isProductionAvailable {
                Picker("Flow", selection: $flow) {
                    ForEach(Flow.allCases) { item in
                        Text(item.title).tag(item)
                    }
                }
                .pickerStyle(.segmented)
                .onChange(of: flow) { _, _ in env.clearAuthError() }

                credentialFields

                if flow == .createCompany {
                    companyFields
                }

                if flow == .join {
                    joinFields
                }

                submitButton

                if flow == .signIn {
                    Button("Forgot password?") {
                        Task { await env.requestPasswordReset(email: email) }
                    }
                    .font(.footnote.weight(.medium))
                    .foregroundStyle(Theme.primary)
                    .disabled(email.isEmpty || env.authPhase.isBusy)
                }

                if let notice = env.signUpNotice {
                    Text(notice)
                        .font(.footnote)
                        .foregroundStyle(Theme.green)
                        .fixedSize(horizontal: false, vertical: true)
                }

                if let notice = env.passwordResetNotice {
                    Text(notice)
                        .font(.footnote)
                        .foregroundStyle(Theme.green)
                        .fixedSize(horizontal: false, vertical: true)
                }

                if let notice = env.accountDeletedNotice {
                    Text(notice)
                        .font(.footnote)
                        .foregroundStyle(Theme.green)
                        .fixedSize(horizontal: false, vertical: true)
                        .accessibilityIdentifier("signIn.accountDeleted")
                }

                if let error = env.authPhase.errorMessage {
                    Text(error)
                        .font(.footnote)
                        .foregroundStyle(Theme.red)
                        .fixedSize(horizontal: false, vertical: true)
                }

                footnote
            } else {
                notConfigured
            }
        }
        // An invitation tapped in an email lands here. The code is copied into
        // the form once and then released, so a later redraw never overwrites
        // something the person has since typed.
        .onChange(of: env.pendingInvitationLink) { _, payload in
            adopt(payload)
        }
        // A confirmation email has gone out. Whatever form they were on, the
        // next thing they need on their return is Sign in — see below.
        .onChange(of: env.pendingEmailConfirmation) { _, address in
            awaitConfirmation(of: address)
        }
        .onAppear {
            adopt(env.pendingInvitationLink)
            awaitConfirmation(of: env.pendingEmailConfirmation)
        }
    }

    private func adopt(_ payload: InvitationLink.Payload?) {
        guard let payload else { return }
        flow = .join
        joinCode = payload.token
        if !payload.name.isEmpty, joinName.trimmingCharacters(in: .whitespaces).isEmpty {
            joinName = payload.name
        }
        env.consumePendingInvitationLink()
    }

    /// Moves the form to Sign in once a confirmation email has been sent.
    ///
    /// This is the fix for coming back from the inbox and finding Join still
    /// on screen. Join is not merely the wrong tab at that point, it is a dead
    /// end: the invitation code is parked on the identity and spent by the
    /// first authenticated session, so redeeming it a second time fails. The
    /// person's real next step is to sign in with the email and password they
    /// just chose, and the join completes itself server-side.
    ///
    /// The email is carried across so they are typing one field, not three.
    /// Everything invitation-specific is cleared, because none of it applies to
    /// a sign-in.
    private func awaitConfirmation(of address: String?) {
        guard let address, !address.isEmpty else { return }
        flow = .signIn
        email = address
        password = ""
        joinCode = ""
        joinName = ""
        env.consumePendingEmailConfirmation()
    }

    private var credentialFields: some View {
        VStack(spacing: 0) {
            TextField("Work email", text: $email)
                .textContentType(.emailAddress)
                .keyboardType(.emailAddress)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .padding(.horizontal, 14)
                .frame(minHeight: Theme.minTap)

            Divider().padding(.leading, 14)

            SecureField("Password", text: $password)
                .textContentType(flow == .signIn ? .password : .newPassword)
                .padding(.horizontal, 14)
                .frame(minHeight: Theme.minTap)
        }
        .cardSurface()
    }

    private var companyFields: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Your company")
                .sectionLabelStyle()

            VStack(spacing: 0) {
                TextField("Your name", text: $ownerName)
                    .textContentType(.name)
                    .padding(.horizontal, 14)
                    .frame(minHeight: Theme.minTap)

                Divider().padding(.leading, 14)

                TextField("Company name", text: $companyName)
                    .textContentType(.organizationName)
                    .padding(.horizontal, 14)
                    .frame(minHeight: Theme.minTap)

                Divider().padding(.leading, 14)

                Picker("Trade", selection: $trade) {
                    ForEach(Trade.allCases) { item in
                        Text(item.title).tag(item)
                    }
                }
                .padding(.horizontal, 14)
                .frame(minHeight: Theme.minTap)

                Divider().padding(.leading, 14)

                Picker("Country", selection: $market) {
                    ForEach(SupportedMarket.allCases) { item in
                        Text(item.countryName).tag(item)
                    }
                }
                .padding(.horizontal, 14)
                .frame(minHeight: Theme.minTap)
                // Choosing a country sets the currency it trades in. It stays a
                // separate, explicit value — a business may invoice in another
                // currency — but it is never left to be typed from scratch.
                .onChange(of: market) { _, newValue in
                    currencyCode = newValue.defaultCurrencyCode
                }

                Divider().padding(.leading, 14)

                Picker("Currency", selection: $currencyCode) {
                    ForEach(Self.selectableCurrencyCodes, id: \.self) { code in
                        Text(code).tag(code)
                    }
                }
                .padding(.horizontal, 14)
                .frame(minHeight: Theme.minTap)
            }
            .cardSurface()

            Text("You'll be the owner of this company. Your role and company are assigned by the server, not by this app.")
                .font(.caption)
                .foregroundStyle(Theme.meta)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    private var joinFields: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Join a company")
                .sectionLabelStyle()

            VStack(spacing: 0) {
                TextField("Your name", text: $joinName)
                    .textContentType(.name)
                    .padding(.horizontal, 14)
                    .frame(minHeight: Theme.minTap)

                Divider().padding(.leading, 14)

                TextField("Join code", text: $joinCode)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .font(.system(.body, design: .monospaced))
                    .padding(.horizontal, 14)
                    .frame(minHeight: Theme.minTap)
            }
            .cardSurface()

            Text("Your invitation email carries this code — tapping the link in it fills this in for you. It decides which company you join and what you can do; this app cannot choose either. The password you enter above is your own, and nobody at your company can see it.")
                .font(.caption)
                .foregroundStyle(Theme.meta)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    /// The single action on the whole screen, so it carries the accent.
    ///
    /// Bold at this size is WCAG "large text", which is what keeps white
    /// legible on the orange fill.
    private var submitButton: some View {
        Button {
            Task { await submit() }
        } label: {
            HStack(spacing: 8) {
                if env.authPhase.isBusy { ProgressView().tint(.white) }
                Text(submitTitle)
                    .font(.body.weight(.bold))
            }
            .frame(maxWidth: .infinity)
            .frame(height: Theme.minTap)
            .background(canSubmit ? Theme.accent : Theme.accent.opacity(0.35))
            .foregroundStyle(.white)
            .clipShape(.rect(cornerRadius: Theme.buttonRadius))
        }
        .buttonStyle(PressableTileStyle())
        .disabled(!canSubmit)
    }

    private var submitTitle: String {
        switch flow {
        case .signIn: return "Sign in"
        case .join: return "Join company"
        case .createCompany: return "Create company"
        }
    }

    private var footnote: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Connected to \(BackendConfiguration.summary).")
            Text("Your company and role are read from the database on every sign-in. This app cannot choose either one.")
        }
        .font(.caption)
        .foregroundStyle(Theme.meta)
        .fixedSize(horizontal: false, vertical: true)
        .padding(.top, 4)
    }

    private var notConfigured: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Production sign-in unavailable")
                .font(.body.weight(.semibold))
                .foregroundStyle(Theme.ink)
            Text("This build wasn't given Supabase credentials, so there is nothing to authenticate against. Development sign-in still works.")
                .font(.footnote)
                .foregroundStyle(Theme.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .cardSurface()
    }

    private func submit() async {
        switch flow {
        case .signIn:
            await env.signInToProduction(email: email, password: password)
        case .join:
            await env.joinCompany(
                InvitationRedemption(
                    email: email,
                    password: password,
                    name: joinName,
                    token: joinCode
                )
            )
        case .createCompany:
            let registration = CompanyRegistration(
                email: email,
                password: password,
                ownerName: ownerName,
                companyName: companyName,
                trade: trade,
                countryCode: market.countryCode,
                currencyCode: currencyCode.uppercased()
            )
            await env.signUpToProduction(registration)
        }
        password = ""
    }
}
